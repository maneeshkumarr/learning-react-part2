import React, { useState } from 'react';
import './Home.css';
import { Link } from 'react-router-dom';
import img from './img/logo.svg';
import themeLight from './img/theme-light.png';
import themeDark from './img/theme-dark.png';


export default function Home() {
  const [theme, setTheme] = useState('light');

  const toggleTheme = () => {
    setTheme(theme === 'light' ? 'dark' : 'light');
  };



  return (
    <div className={`container ${theme}`}>
      <div className="top-right-buttons">
        <button className="theme-toggle" onClick={toggleTheme} style={{ backgroundImage: `url(${theme === 'light' ? themeDark : themeLight})` }}>
          {/* No need to show theme text inside the button */}
        </button>
      </div>
      <div className="content">
        <div className="jus">
          <Link to="/ArrayFunction"><button className="arrow">Arrow Function</button></Link>
          <Link to="/ArrayMethod"><button className="arrow">Array Method</button></Link>
          <Link to="/Destructure"><button className="arrow">Destructure</button></Link>
          <Link to="/SpreadOperator"><button className="arrow">Spread Operator</button></Link>
          <Link to="/Ternary"><button className="arrow">Ternary Operator</button></Link>
          <Link to="/Mui"><button className="arrow">MUI</button></Link>
          <Link to="/Muitable"><button className="arrow">MUI table</button></Link>
          <Link to="/Effect"><button className="arrow">Effect</button></Link>
          <Link to="/Local"><button className="arrow">Local</button></Link>
          <Link to="/Quotes"><button className="arrow">Quotes</button></Link>
        </div>

        <div className="App">
          <header className="App-header">
            <img src={img} className="App-logo" alt="logo" />
            <p>
              <br /><br />
              <h3>React WorkShop</h3>
            </p>
            <a
              className="App-link"
              href="https://reactjs.org"
              target="_blank"
              rel="noopener noreferrer"
            >
              Learn React
            </a>
          </header>
        </div>
      </div>
    </div>
  );
}
