
//Inline Export
export const greet="Good Morning";
export const ananth="How are You!!";

const val=1;
const val2=5;

//Grouped Export [named export]

export {val,val2};