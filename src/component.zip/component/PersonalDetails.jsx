import React from 'react'
import Props from './Props'
export default function PersonalDetails({address}) {
  return (


    <div><h1>My name is {address}</h1></div>
  )
}
