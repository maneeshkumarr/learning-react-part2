import React from 'react'
import Props from './Props'

export default function Additional({address}) {
  return (
    <div>Additional

<Props/>
    </div>
  )
}
